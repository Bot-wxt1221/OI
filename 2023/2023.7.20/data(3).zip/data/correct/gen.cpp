#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <iostream>
#include <algorithm>
#include <ctime>
using namespace std;

#define GENPRNG_MT_LENGTH 624

//PRNG
class GenPRNG {
	friend class GenPRNGPool;
private :
	//the mersenne table
	int MT[GENPRNG_MT_LENGTH];
	int idx;

    /**
    * @brief Initialize the PRNG with seed given.
    */
	void initialize(int seed);

	/**
	* @brief Re-generate the table.
	*/
	void genTable();

protected :
	bool occupied;

public :
    /**
    * @brief
    */
	GenPRNG();

	/**
	* @brief Initialize the PRNG with seed given.
	* @param seed  The seed.
	*/
	GenPRNG(int seed);

    /**
    * @brief Initialize the PRNG with seed given.
    * @param seed  The seed.
    */
	void setSeed(int seed);

	/**
	* @brief Generate a PRN.
	* @return The PRN generated.
	*/
	int getRandom();
};

GenPRNG::GenPRNG() {
	initialize(0xffffffff);
}

GenPRNG::GenPRNG(int seed) {
	initialize(seed);
}

void GenPRNG::initialize(int seed) {
	idx = 0;

	MT[0] = seed;
	for (int i = 1; i < GENPRNG_MT_LENGTH; ++i) {
         MT[i] = (1812433253ull * (MT[i-1] ^ (MT[i-1] >> 30)) + i) & 0xffffffff; // 0x6c078965
    }
}

void GenPRNG::genTable() {
     for (int i = 0; i < GENPRNG_MT_LENGTH; ++i) {
         int y = (MT[i] & 0x80000000) + (MT[(i + 1) % 624] & 0x7fffffff);
         MT[i] = MT[(i + 397) % 624] ^ (y >> 1);

		 if (y & 1) {
             MT[i] = MT[i] ^ (2567483615u); // 0x9908b0df
         }
     }
}

int GenPRNG::getRandom() {
	if (!idx) genTable();

	unsigned y = MT[idx];
    y ^= (y >> 11);
    y ^= ((y << 7) & 2636928640u); // 0x9d2c5680
    y ^= ((y << 15) & 4022730752u); // 0xefc60000
    y ^= (y >> 18);

    if (++idx == GENPRNG_MT_LENGTH) idx = 0;
	return y;
}

void GenPRNG::setSeed(int seed) {
	initialize(seed);
}

GenPRNG random;
//End PRNG

//Global Variables & Definitions
const char *probname = "correct", *exec_suffix = ".exe", *input_suffix = ".in", *output_suffix = ".out";
int s = 1, t = 20;

char t_inname[50], t_ouname[50];
char exec_fullname[50], i_fullname[50], o_fullname[50];

char t_rncmdi[50], t_rncmdo[50];
//End Global Variables & Definitions

//= =
int genNstar() {
	int i = -1;
	while (i < 0) i = random.getRandom();
	return i;
}

void genCase(int i) {
	int N = i * 50, M = i * 50;
redo:
	printf("%d %d\n", N, M);
	for (int i = 0; i < M; ++i) {
		int a = 0, b = 0;
		while (a == b) {
			a = genNstar() % N + 1; b = genNstar() % N + 1;
		}
		
		printf("%d %d\n", a, b);
	}
	
	fclose(stdout);
	
	if (system("correct")) {
		freopen(i_fullname, "w", stdout);
		goto redo;
	}
}
//End = =

//Main Structure
void genName(int i) {
	sprintf(t_inname, "%s%d%s", probname, i, input_suffix);
	sprintf(t_ouname, "%s%d%s", probname, i, output_suffix);
	
	sprintf(t_rncmdi, "copy %s%s %s > nul && del %s%s", probname, input_suffix, t_inname, probname, input_suffix);
	sprintf(t_rncmdo, "copy %s%s %s > nul && del %s%s", probname, output_suffix, t_ouname, probname, output_suffix);
}

void genInput(int i) {
	freopen(i_fullname, "w", stdout);
	
	genCase(i);
	
	fclose(stdout);
}

int main() {
	random.setSeed(time(NULL));
	sprintf(exec_fullname, "%s%s", probname, exec_suffix);
	sprintf(i_fullname, "%s%s", probname, input_suffix);
	sprintf(o_fullname, "%s%s", probname, output_suffix);
	
	FILE *o = stderr;
	
	for (int i = s; i <= t; ++i) {
		fprintf(o, "Case %d, Generating...", i);
		
		genName(i);
		genInput(i);
		
		fprintf(o, "done. Running...");
		
		if (system(exec_fullname)) fprintf(o, "Error!\n");
		else {
			fprintf(o, "done!\n");
			system(t_rncmdi); system(t_rncmdo);
		}
	}
	
	return 0;
}

