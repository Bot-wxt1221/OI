#include <cstdio>
#include <set>
#include <algorithm>
typedef std::pair<int, int> PII;
#include <cstdlib>
#include <ctime>
std::set<PII> S;

#define f(x, y, z) for(int x = (y); x <= (z); ++x)

inline unsigned long long ran(){return (((rand() * RAND_MAX + rand()) * RAND_MAX + rand()) * RAND_MAX + rand()) * RAND_MAX + rand();}

int maxn, maxm; long long maxt, h;

int main(){
	scanf("%d%d%I64d", &maxn, &maxm, &maxt);
	srand(time(0));
	int n = maxn / 2 + ran() % (maxn / 2 + 1) + 1, m = maxm / 2 + ran() % (maxm / 2 + 1) + 1;
	long long t = maxt / 2 + ran() % (maxt / 2 + 1) + 1;
	printf("%d %d %I64d\n", n, m, t);
	f(i, 1, n){
		int cx, cy;
		do{
			bool flag = false;
			if((ran() % 10) && t < m){
				flag = true; h = m; m = t / 100; t = h;
			}
			if(ran() % 10) cx = cx = (ran() % (2 * (m / (m / 10)) + 1) - m / (m / 10)) * (m / 10);
			else cx = ran() % (2 * m + 1) - m;
			if(ran() % 10) cy = cy = (ran() % (2 * (m / (m / 10)) + 1) - m / (m / 10)) * (m / 10);
			else cy = ran() % (2 * m + 1) - m;
			if(flag){h = m; m = t; t = h * 100;}
		}while(S.count(PII(cx, cy)) || (cx == 0 && cy == 0));
		S.insert(PII(cx, cy));
		printf("%d %d %c\n", cx, cy, (ran() % 2) ? '/' : '\\');
	}
	return 0;
}
