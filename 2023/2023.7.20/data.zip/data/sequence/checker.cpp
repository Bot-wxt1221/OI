#include "testlib.h"

int cnt;
long long seq[105];

int main(int argc, char* argv[])
{
    registerTestlibCmd(argc, argv);
    int T = inf.readInt(); inf.readEoln();
    while(T --)
    {
    	long long val = inf.readLong();
    	int p = 2;
		int q = 3;
    	cnt = 0;
    	long long sum = 0;
    	while(1)
    	{
    		long long valx = ans.readLong();// ouf.readLong(); 
    		if(valx < 0) quitf(_wa, "Outputed negative number.\n");
    		long long tmp = valx;
    		while(tmp % p == 0) tmp /= p;
    		while(tmp % q == 0) tmp /= q;
    		if(tmp != 1) quitf(_wa, "The Implementation is incorrect.\n");
    		sum += valx;
    		if(valx > val || sum < 0 || sum > val) quitf(_wa, "The implementation is incorrect.\n");
    		seq[++ cnt] = valx;
    		if(sum == val) break;
    		ans.readSpace(); 
    	//	ouf.readSpace();
		}
		ans.readEoln();// ouf.readEoln();
		sum = 0;
		while(1)
    	{
    		long long valx = ouf.readLong();// ouf.readLong(); 
    		if(valx < 0) quitf(_wa, "Outputed negative number.\n");
    		long long tmp = valx;
    		while(tmp % p == 0) tmp /= p;
    		while(tmp % q == 0) tmp /= q;
    		if(tmp != 1) quitf(_wa, "The Implementation is incorrect.\n");
    		sum += valx;
    		if(valx > val || sum < 0 || sum > val) quitf(_wa, "The implementation is incorrect.\n");
    	//	seq[++ cnt] = valx;
    		if(sum == val) break;
    		ouf.readSpace(); 
    	//	ouf.readSpace();
		}
		ouf.readEoln();// ouf.readEoln();
		for(int i = 1;i <= cnt; ++ i)
			for(int j = i + 1;j <= cnt; ++ j)
				if(seq[j] % seq[i] == 0 || seq[i] % seq[j] == 0)
					quitf(_wa, "The implementation is incorrect.\n");
	}
    if(ouf.eof())
	    quitf(_ok, "Ok Correct.\n");
	else
		quitf(_wa, "Outputed something more.\n");
    return 0;

}
