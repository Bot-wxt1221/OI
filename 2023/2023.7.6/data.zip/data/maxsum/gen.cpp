#include <bits/stdc++.h>
using namespace std;

int main(){
	srand((unsigned int)time(NULL));
	freopen("maxsum10.in", "w", stdout);
	int T = rand() % 20 + 1;
	cout << T << endl;

	for(int i = 1; i <= T; i++){
		int N = 100000;
		cout << N  << " ";
		for(int j = 1; j <= N; j++){
			cout << rand() % (2000 + 1) - 1000 << " ";
		}
		cout << endl;
	}	
	
	return 0;
} 
